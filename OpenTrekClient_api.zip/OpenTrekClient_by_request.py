import requests
import hmac
import hashlib
import base64
from datetime import datetime
from urllib.parse import quote_plus

def sign(secret, to_sign):
    h = hmac.new(secret.encode('utf-8'), to_sign.encode('utf-8'), hashlib.sha1)
    return base64.b64encode(h.digest()).decode('utf-8')

def call_opentrek_api(access_key_id, access_key_secret, endpoint, path, params):
    # 构造规范化的查询字符串
    sorted_params = sorted(params.items())
    query_string = '&'.join([f'{k}={quote_plus(str(v))}' for k, v in sorted_params])
    
    # 构造签名字符串
    now = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    canonicalized_resource = path
    string_to_sign = f"GET\n\n\n{now}\n{canonicalized_resource}?{query_string}"
    
    # 计算签名
    signature = sign(access_key_secret, string_to_sign)
    
    # 构造请求头
    headers = {
        'Authorization': f'acs {access_key_id}:{signature}',
        'Date': now,
        'Accept': 'application/json'
    }
    
    # 发送请求
    url = f'https://{endpoint}{path}?{query_string}'
    response = requests.get(url, headers=headers)
    return response.json()

# 使用示例
if __name__ == '__main__':
    result = call_opentrek_api(
        access_key_id='your_access_key_id',
        access_key_secret='your_access_key_secret',
        endpoint='opentrek.aliyuncs.com',
        path='/v1/geocode/query',
        params={
            'address': '北京市海淀区丹棱街1号',
            'output': 'json'
        }
    )
    print(result)
    