from alibabacloud_tea_openapi.client import Client as OpenApiClient
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_tea_util.client import Client as UtilClient
from alibabacloud_tea_util import models as util_models

class OpenTrekClient:
    def __init__(self):
        # 初始化配置
        config = open_api_models.Config(
            access_key_id='your_access_key_id',       # 替换为你的AccessKey ID
            access_key_secret='your_access_key_secret', # 替换为你的AccessKey Secret
            endpoint='opentrek.aliyuncs.com',         # OpenTrek服务Endpoint
            region_id='cn-hangzhou'                  # 区域ID
        )
        self.client = OpenApiClient(config)
    
    def call_api(self, path, params):
        """
        调用OpenTrek API
        :param path: API路径，如'/v1/geocode/query'
        :param params: 请求参数
        :return: API响应
        """
        # 构造请求
        request = open_api_models.OpenApiRequest(
            query=params
        )
        
        # 运行时选项
        runtime = util_models.RuntimeOptions()
        
        try:
            # 调用API
            response = self.client.call_api(
                path=path,
                method='GET',  # 根据API文档选择GET或POST
                request=request,
                runtime=runtime
            )
            return response
        except Exception as e:
            print(e)
            return None

# 使用示例
if __name__ == '__main__':
    client = OpenTrekClient()
    
    # 示例：地理编码查询
    params = {
        'address': '北京市海淀区丹棱街1号',
        'output': 'json'
    }
    response = client.call_api('/v1/geocode/query', params)
    
    if response:
        print(response.body)
        