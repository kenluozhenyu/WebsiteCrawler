import requests
import os
import time
import base64
import logging
from urllib.parse import urljoin

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ConfluencePageTree:
    def __init__(self, base_url, username, password):
        """
        初始化Confluence页面树爬虫
        
        Args:
            base_url: Confluence站点的基础URL
            username: Confluence登录用户名
            password: Confluence登录密码
        """
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.session = requests.Session()
        
        # 设置认证头
        auth_str = f"{username}:{password}"
        self.auth_header = {
            'Authorization': f'Basic {base64.b64encode(auth_str.encode()).decode()}'
        }
        
        # 已访问的页面ID集合，避免重复爬取
        self.visited_pages = set()

    def login(self):
        """登录到Confluence"""
        try:
            # 尝试访问API获取当前用户信息，测试认证
            resp = self.session.get(
                f"{self.base_url}/rest/api/user/current",
                headers=self.auth_header
            )
            resp.raise_for_status()
            logger.info(f"登录成功: {resp.json().get('displayName', '未知用户')}")
            return True
        except Exception as e:
            logger.error(f"登录失败: {e}")
            return False
    
    def get_space_homepage(self, space_key):
        """获取Confluence空间的主页ID"""
        try:
            resp = self.session.get(
                f"{self.base_url}/rest/api/space/{space_key}",
                headers=self.auth_header
            )
            resp.raise_for_status()
            
            space_data = resp.json()
            homepage_id = space_data.get('homepage', {}).get('id')
            
            if not homepage_id:
                logger.error(f"无法找到空间 {space_key} 的主页")
                return None
                
            return homepage_id
        except Exception as e:
            logger.error(f"获取空间主页失败: {e}")
            return None
    
    def get_page_children(self, page_id):
        """获取页面的所有子页面"""
        try:
            children = []
            start = 0
            limit = 100
            
            while True:
                resp = self.session.get(
                    f"{self.base_url}/rest/api/content/{page_id}/child/page",
                    params={'start': start, 'limit': limit},
                    headers=self.auth_header
                )
                resp.raise_for_status()
                
                data = resp.json()
                results = data.get('results', [])
                children.extend(results)
                
                # 处理分页
                if len(results) < limit:
                    break
                start += limit
            
            return children
        except Exception as e:
            logger.error(f"获取页面 {page_id} 的子页面失败: {e}")
            return []
    
    def print_page_tree(self, page_id, indent=0, parent_path=""):
        """递归打印页面树结构"""
        # 避免重复爬取
        if page_id in self.visited_pages:
            logger.info(f"页面 {page_id} 已经爬取过，跳过")
            return
        
        self.visited_pages.add(page_id)
        
        try:
            # 获取页面信息
            resp = self.session.get(
                f"{self.base_url}/rest/api/content/{page_id}",
                params={'expand': 'title,version'},
                headers=self.auth_header
            )
            resp.raise_for_status()
            
            page_data = resp.json()
            page_title = page_data.get('title', f"未命名页面_{page_id}")
            page_version = page_data.get('version', {}).get('number', 'N/A')
            page_url = f"{self.base_url}/pages/viewpage.action?pageId={page_id}"
            
            # 打印当前页面信息
            prefix = '  ' * indent
            print(f"{prefix}|- {page_title} (ID: {page_id}, 版本: {page_version})")
            print(f"{prefix}   URL: {page_url}")
            
            # 构建当前路径
            current_path = os.path.join(parent_path, page_title) if parent_path else page_title
            
            # 获取子页面
            children = self.get_page_children(page_id)
            
            if children:
                print(f"{prefix}   子页面数量: {len(children)}")
                
                # 递归处理子页面
                for child in children:
                    child_id = child.get('id')
                    if child_id:
                        self.print_page_tree(child_id, indent + 1, current_path)
            else:
                print(f"{prefix}   (无子页面)")
                
        except Exception as e:
            logger.error(f"获取页面 {page_id} 信息失败: {e}")
    
    def print_space_tree(self, space_key):
        """打印整个空间的页面树结构"""
        homepage_id = self.get_space_homepage(space_key)
        if homepage_id:
            print(f"\n=== 空间 {space_key} 的页面树结构 ===\n")
            self.print_page_tree(homepage_id)
            print(f"\n=== 页面树结构打印完成 ===")
            print(f"总计爬取页面数: {len(self.visited_pages)}")
        else:
            logger.error(f"无法找到空间 {space_key} 的主页")
    
    def get_all_spaces(self):
        """获取所有可用的空间列表"""
        try:
            spaces = []
            start = 0
            limit = 50
            
            print("\n=== 可用空间列表 ===\n")
            
            while True:
                resp = self.session.get(
                    f"{self.base_url}/rest/api/space",
                    params={
                        'start': start, 
                        'limit': limit,
                        'type': 'global'  # 获取全局空间
                    },
                    headers=self.auth_header
                )
                resp.raise_for_status()
                
                data = resp.json()
                results = data.get('results', [])
                
                for space in results:
                    space_key = space.get('key')
                    space_name = space.get('name')
                    print(f"空间键: {space_key}, 名称: {space_name}")
                    spaces.append((space_key, space_name))
                
                # 处理分页
                if len(results) < limit:
                    break
                start += limit
            
            print(f"\n共找到 {len(spaces)} 个空间")
            return spaces
            
        except Exception as e:
            logger.error(f"获取空间列表失败: {e}")
            return []
    
    def close(self):
        """关闭资源"""
        self.session.close()


if __name__ == "__main__":
    # 配置参数
    CONFLUENCE_URL = "https://your-confluence-site.com"  # 替换为你的Confluence URL
    USERNAME = "your_username"  # 替换为你的用户名
    PASSWORD = "your_password"  # 替换为你的密码
    
    try:
        tree_crawler = ConfluencePageTree(CONFLUENCE_URL, USERNAME, PASSWORD)
        if tree_crawler.login():
            # 列出所有可用空间
            spaces = tree_crawler.get_all_spaces()
            
            if spaces:
                # 用户选择要查看的空间
                print("\n请选择要查看的空间 (输入空间键):")
                space_key = input("> ").strip()
                
                # 打印选定空间的页面树
                tree_crawler.print_space_tree(space_key)
            else:
                print("没有找到可用空间，或者您没有查看空间列表的权限")
        else:
            logger.error("登录失败，无法继续操作")
    finally:
        if 'tree_crawler' in locals():
            tree_crawler.close()