import requests
import re
import base64
import logging
import urllib3
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 禁用不安全连接警告（仅在处理自签名证书时使用）
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ConfluenceLinkCrawler:
    def __init__(self, base_url, username, password, verify_ssl=False, max_depth=3):
        """
        初始化Confluence链接爬虫
        
        Args:
            base_url: Confluence站点的基础URL
            username: Confluence登录用户名
            password: Confluence登录密码
            verify_ssl: 是否验证SSL证书（默认不验证，适用于自签名证书）
            max_depth: 最大爬取深度
        """
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.max_depth = max_depth
        self.session = requests.Session()
        
        # 设置认证头
        auth_str = f"{username}:{password}"
        self.auth_header = {
            'Authorization': f'Basic {base64.b64encode(auth_str.encode()).decode()}'
        }
        
        # 已访问的页面集合，避免重复爬取
        self.visited_pages = set()
        # 已发现的页面集合，包括待访问的
        self.discovered_pages = set()

    def login(self):
        """登录到Confluence"""
        try:
            # 尝试访问API获取当前用户信息，测试认证
            resp = self.session.get(
                f"{self.base_url}/rest/api/user/current",
                headers=self.auth_header,
                verify=self.verify_ssl
            )
            resp.raise_for_status()
            logger.info(f"登录成功: {resp.json().get('displayName', '未知用户')}")
            return True
        except Exception as e:
            logger.error(f"登录失败: {e}")
            return False
    
    def extract_page_id(self, url):
        """从URL中提取Confluence页面ID"""
        parsed_url = urlparse(url)
        
        # 检查是否是viewpage.action URL
        if 'viewpage.action' in parsed_url.path:
            query_params = parse_qs(parsed_url.query)
            if 'pageId' in query_params:
                return query_params['pageId'][0]
        
        # 尝试从路径中提取页面ID（针对某些Confluence实例）
        path_parts = parsed_url.path.split('/')
        if len(path_parts) > 1 and path_parts[-1].isdigit():
            return path_parts[-1]
        
        return None
    
    def is_confluence_page_link(self, url):
        """判断是否是指向Confluence页面的链接"""
        parsed_url = urlparse(url)
        
        # 检查是否是内部链接
        if not parsed_url.netloc or parsed_url.netloc in self.base_url:
            # 检查是否是页面链接
            return ('viewpage.action' in url or 
                    '/pages/' in url or 
                    '/display/' in url or 
                    '/spaces/' in url)
        
        return False

    def get_page_content(self, page_id):
        """获取页面内容"""
        try:
            # 先获取页面标题和其他元数据
            resp = self.session.get(
                f"{self.base_url}/rest/api/content/{page_id}",
                params={'expand': 'title,body.view,version'},
                headers=self.auth_header,
                verify=self.verify_ssl
            )
            resp.raise_for_status()
            page_data = resp.json()
            
            title = page_data.get('title', f"未命名页面_{page_id}")
            version = page_data.get('version', {}).get('number', 'N/A')
            
            # 获取HTML内容
            body = page_data.get('body', {}).get('view', {}).get('value', '')
            
            return {
                'id': page_id,
                'title': title,
                'version': version,
                'content': body,
                'url': f"{self.base_url}/pages/viewpage.action?pageId={page_id}"
            }
        except Exception as e:
            logger.error(f"获取页面 {page_id} 内容失败: {e}")
            return None
    
    def extract_links(self, html_content, base_url):
        """从HTML内容中提取所有链接"""
        soup = BeautifulSoup(html_content, 'html.parser')
        links = []
        
        # 提取所有链接
        for a_tag in soup.find_all('a', href=True):
            href = a_tag.get('href')
            
            # 处理相对链接
            full_url = urljoin(base_url, href)
            
            # 只保留Confluence页面链接
            if self.is_confluence_page_link(full_url):
                links.append(full_url)
        
        return links
    
    def crawl_page(self, page_id, current_depth=0):
        """爬取单个页面及其链接"""
        # 检查爬取深度
        if current_depth > self.max_depth:
            return
        
        # 避免重复访问
        if page_id in self.visited_pages:
            return
        
        self.visited_pages.add(page_id)
        self.discovered_pages.add(page_id)
        
        # 获取页面内容
        page_info = self.get_page_content(page_id)
        if not page_info:
            return
        
        # 打印页面信息
        indent = '  ' * current_depth
        print(f"{indent}[层级 {current_depth}] 页面: {page_info['title']} (ID: {page_id})")
        print(f"{indent}  URL: {page_info['url']}")
        print(f"{indent}  版本: {page_info['version']}")
        
        # 如果已达到最大深度，不再提取链接
        if current_depth >= self.max_depth:
            return
        
        # 提取页面中的链接
        links = self.extract_links(page_info['content'], page_info['url'])
        unique_links = set()
        
        for link in links:
            link_page_id = self.extract_page_id(link)
            if link_page_id and link_page_id not in self.visited_pages and link_page_id not in unique_links:
                unique_links.add(link_page_id)
        
        # 显示提取的链接数量
        if unique_links:
            print(f"{indent}  发现 {len(unique_links)} 个未访问的链接")
        else:
            print(f"{indent}  未发现新链接")
        
        # 递归爬取链接
        for link_page_id in unique_links:
            self.crawl_page(link_page_id, current_depth + 1)
    
    def start_crawl(self, start_page_id):
        """从指定页面开始爬取"""
        print(f"\n=== 开始从页面ID {start_page_id} 爬取 (最大深度: {self.max_depth}) ===\n")
        self.crawl_page(start_page_id)
        print(f"\n=== 爬取完成 ===")
        print(f"共访问 {len(self.visited_pages)} 个页面")
        print(f"共发现 {len(self.discovered_pages)} 个页面")


if __name__ == "__main__":
    # 配置参数
    CONFLUENCE_URL = "https://your-confluence-site.com"  # 替换为你的Confluence URL
    USERNAME = "your_username"  # 替换为你的用户名
    PASSWORD = "your_password"  # 替换为你的密码
    VERIFY_SSL = False  # 设置为False以禁用SSL证书验证（适用于自签名证书）
    MAX_DEPTH = 3  # 最大爬取深度，设置为3表示最多爬取3层
    
    try:
        print("请输入要爬取的Confluence页面ID:")
        print("(从URL中获取，例如 /pages/viewpage.action?pageId=12345 中的 12345)")
        start_page_id = input("> ").strip()
        
        crawler = ConfluenceLinkCrawler(CONFLUENCE_URL, USERNAME, PASSWORD, VERIFY_SSL, MAX_DEPTH)
        if crawler.login():
            crawler.start_crawl(start_page_id)
        else:
            logger.error("登录失败，无法继续操作")
    except KeyboardInterrupt:
        print("\n爬取被用户中断")
    except Exception as e:
        logger.error(f"爬取过程中发生错误: {e}")