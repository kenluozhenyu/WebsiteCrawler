import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import os
import re

class ConfluenceNavParser:
    def __init__(self, base_url, username, password, space_key):
        self.base_url = base_url.rstrip('/')
        self.space_key = space_key
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.headers.update({'User-Agent': 'Mozilla/5.0'})

    def _get_page_html(self, url):
        """获取页面HTML"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"请求失败: {url} - {str(e)}")
            return None

    def _parse_nav_menu(self, html):
        """解析导航菜单的页面树结构"""
        soup = BeautifulSoup(html, 'html.parser')
        nav_tree = {}

        # 定位Confluence的导航栏（根据实际HTML结构调整选择器）
        nav = soup.select_one('#navigation-menu, .page-tree, .space-menu')
        if not nav:
            return nav_tree

        # 递归解析导航树
        def _parse_items(items, depth=0):
            pages = {}
            for item in items:
                link = item.select_one('a[href]')
                if not link:
                    continue
                
                page_url = urljoin(self.base_url, link['href'])
                page_title = link.text.strip()
                
                # 过滤非当前空间的链接
                if f"/display/{self.space_key}/" not in page_url:
                    continue
                
                pages[page_title] = {
                    'url': page_url,
                    'children': {}
                }

                # 查找子菜单（根据实际HTML结构调整）
                submenu = item.select_one('ul, .child-pages')
                if submenu:
                    pages[page_title]['children'] = _parse_items(
                        submenu.select('li'), 
                        depth + 1
                    )
            return pages

        return _parse_items(nav.select('li'))

    def get_full_page_tree(self):
        """获取完整的页面树"""
        # 先访问空间首页获取导航结构
        space_url = f"{self.base_url}/display/{self.space_key}"
        html = self._get_page_html(space_url)
        if not html:
            return {}

        return self._parse_nav_menu(html)

    def print_tree(self, tree, indent=0):
        """打印页面树结构"""
        for title, info in tree.items():
            print('  ' * indent + f"📄 {title} ({info['url']})")
            self.print_tree(info['children'], indent + 1)

# 使用示例
if __name__ == "__main__":
    crawler = ConfluenceNavParser(
        base_url="https://wiki.your-company.com",
        username="your-username",
        password="your-password",
        space_key="DEV"
    )
    page_tree = crawler.get_full_page_tree()
    crawler.print_tree(page_tree)