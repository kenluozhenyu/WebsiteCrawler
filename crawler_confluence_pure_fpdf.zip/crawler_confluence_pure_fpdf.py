import os
import re
import time
import random
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from fpdf import FPDF

class ConfluencePageCrawler:
    def __init__(self, base_url, username, password, start_page_id, max_depth=3, output_dir="confluence_pdfs"):
        """
        :param base_url: Confluence基础URL (如 "https://wiki.your-company.com")
        :param username: 用户名
        :param password: 密码/API Token
        :param start_page_id: 起始页面ID (如 "123456")
        :param max_depth: 最大爬取深度 (默认3层)
        :param output_dir: PDF输出目录
        """
        self.base_url = base_url.rstrip('/')
        self.start_url = f"{self.base_url}/pages/viewpage.action?pageId={start_page_id}"
        self.max_depth = max_depth
        self.output_dir = output_dir
        self.visited_urls = set()
        
        # 配置会话
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'text/html,application/xhtml+xml'
        })

        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)

    def _clean_text(self, text):
        """清理文本中的多余空白和特殊字符"""
        text = re.sub(r'\s+', ' ', text)  # 合并空白字符
        text = re.sub(r'[^\x00-\x7F]+', ' ', text)  # 移除非ASCII字符
        return text.strip()

    def _extract_main_content(self, soup):
        """提取Confluence页面的主要内容"""
        content_selectors = [
            '#main-content',
            '.wiki-content',
            '.content-container',
            'div[data-test-id="content-body"]',
            'div.body'
        ]
        
        for selector in content_selectors:
            content = soup.select_one(selector)
            if content:
                return content.get_text()
        return soup.get_text()  # 回退到整个页面文本

    def _get_page_title(self, soup):
        """提取页面标题"""
        title = soup.find('meta', property='og:title') or soup.title
        return title.get('content', title.text if title else "Untitled").strip()

    def save_as_pdf(self, url):
        """将页面文本保存为PDF"""
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取内容
            title = self._get_page_title(soup)
            content = self._extract_main_content(soup)
            cleaned_text = self._clean_text(content)
            
            # 生成安全文件名
            filename = f"{title[:50]}.pdf".replace('/', '_')
            invalid_chars = r'<>:"\|?*'
            for char in invalid_chars:
                filename = filename.replace(char, '_')
            filepath = os.path.join(self.output_dir, filename)
            
            # 创建PDF
            pdf = FPDF()
            pdf.add_page()
            
            # 添加标题
            pdf.set_font("Arial", 'B', 14)
            pdf.cell(200, 10, txt=title[:100], ln=1)
            pdf.set_font("Arial", size=10)
            pdf.cell(200, 10, txt=url, ln=1)
            pdf.ln(5)
            
            # 添加正文（分块处理）
            chunk_size = 2000
            for i in range(0, len(cleaned_text), chunk_size):
                pdf.multi_cell(0, 5, txt=cleaned_text[i:i+chunk_size])
            
            pdf.output(filepath)
            print(f"✓ 已保存: {filepath}")
            return True
            
        except Exception as e:
            print(f"✗ 处理失败 [{url}]: {str(e)}")
            return False

    def get_page_links(self, url):
        """获取页面中的所有有效链接（限制为同域链接）"""
        try:
            time.sleep(random.uniform(1, 2))  # 反爬延迟
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            links = set()
            for a in soup.find_all('a', href=True):
                href = a['href']
                full_url = urljoin(self.base_url, href)
                
                # 只保留同域且未访问的链接
                if (urlparse(full_url).netloc == urlparse(self.base_url).netloc and
                    full_url not in self.visited_urls and
                    '/pages/viewpage.action' in full_url):
                    links.add(full_url)
            return links
        except Exception as e:
            print(f"链接提取失败: {url} - {str(e)}")
            return set()

    def crawl(self, url, current_depth=1):
        """递归爬取页面"""
        if current_depth > self.max_depth or url in self.visited_urls:
            return
        
        self.visited_urls.add(url)
        print(f"\n深度 {current_depth}: 处理 {url}")
        
        # 保存当前页为PDF
        self.save_as_pdf(url)
        
        # 递归处理子链接
        if current_depth < self.max_depth:
            for link in self.get_page_links(url):
                self.crawl(link, current_depth + 1)

    def start(self):
        """启动爬虫"""
        print(f"🚀 开始爬取起始页面: {self.start_url}")
        self.crawl(self.start_url)
        print(f"\n✅ 完成! 共保存 {len(self.visited_urls)} 个PDF文件到 {self.output_dir}")

if __name__ == "__main__":
    # 配置参数
    CONFLUENCE_URL = "https://wiki.your-company.com"
    USERNAME = "your-username"
    PASSWORD = "your-password"  # 或用API Token
    START_PAGE_ID = "123456"    # 替换为实际页面ID
    
    # 启动爬虫
    crawler = ConfluencePageCrawler(
        base_url=CONFLUENCE_URL,
        username=USERNAME,
        password=PASSWORD,
        start_page_id=START_PAGE_ID,
        max_depth=3
    )
    crawler.start()