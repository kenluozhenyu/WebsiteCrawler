import os
import re
import time
import random
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from fpdf import FPDF

class ConfluenceTextCrawler:
    def __init__(self, base_url, username, password, space_key, max_depth=3, output_dir="confluence_text_pdfs"):
        """
        初始化爬虫 (纯文本版)
        :param base_url: Confluence 基础URL (如 "https://wiki.your-company.com")
        :param username: 用户名
        :param password: 密码或API Token
        :param space_key: 空间Key (如 "DEV")
        :param max_depth: 最大爬取深度
        :param output_dir: PDF输出目录
        """
        self.base_url = base_url.rstrip('/')
        self.space_key = space_key
        self.max_depth = max_depth
        self.output_dir = output_dir
        self.visited_urls = set()
        self.session = requests.Session()
        
        # 认证配置
        self.session.auth = (username, password)
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'text/html,application/xhtml+xml'
        })
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)

    def _clean_text(self, text):
        """清理文本中的多余空白和特殊字符"""
        text = re.sub(r'\s+', ' ', text)  # 合并多个空白字符
        text = re.sub(r'[^\x00-\x7F]+', ' ', text)  # 移除非ASCII字符（可选）
        return text.strip()

    def _extract_main_content(self, soup):
        """提取Confluence页面的主要内容文本"""
        # Confluence 常见内容容器选择器
        containers = [
            '#main-content',
            '.wiki-content',
            '.content-container',
            'div[data-test-id="content-body"]'
        ]
        
        for selector in containers:
            content = soup.select_one(selector)
            if content:
                return content.get_text()
        return soup.get_text()  # 回退到整个页面文本

    def save_as_pdf(self, url):
        """将网页文本保存为PDF"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            # 解析HTML并提取文本
            soup = BeautifulSoup(response.text, 'html.parser')
            page_title = soup.title.string if soup.title else urlparse(url).path.split('/')[-1]
            main_text = self._extract_main_content(soup)
            cleaned_text = self._clean_text(main_text)
            
            # 生成PDF文件名
            filename = f"{page_title[:50]}.pdf".replace('/', '_')
            filepath = os.path.join(self.output_dir, filename)
            
            # 创建PDF
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=10)
            
            # 添加标题
            pdf.set_font("Arial", 'B', 14)
            pdf.cell(200, 10, txt=page_title[:100], ln=1)
            pdf.set_font("Arial", size=10)
            pdf.cell(200, 10, txt=url, ln=1)
            pdf.ln(5)
            
            # 添加正文（分块处理避免超限）
            chunk_size = 2000  # FPDF单次写入限制
            for i in range(0, len(cleaned_text), chunk_size):
                pdf.multi_cell(0, 5, txt=cleaned_text[i:i+chunk_size])
            
            pdf.output(filepath)
            print(f"已保存: {filepath}")
            return True
            
        except Exception as e:
            print(f"PDF生成失败: {url} - {str(e)}")
            return False

    def get_page_links(self, url):
        """获取页面中的所有有效链接"""
        try:
            time.sleep(random.uniform(1, 3))  # 反爬延迟
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            links = set()
            for a in soup.find_all('a', href=True):
                href = a['href']
                if href.startswith(('/display/', '/pages/')):
                    full_url = urljoin(self.base_url, href)
                    if full_url not in self.visited_urls:
                        links.add(full_url)
            return links
        except Exception as e:
            print(f"链接提取失败: {url} - {str(e)}")
            return set()

    def crawl(self, url, current_depth=1):
        """递归爬取页面"""
        if current_depth > self.max_depth or url in self.visited_urls:
            return
        
        self.visited_urls.add(url)
        print(f"\n深度 {current_depth}: 处理 {url}")
        
        # 保存当前页为PDF
        self.save_as_pdf(url)
        
        # 获取并处理子链接
        if current_depth < self.max_depth:
            for link in self.get_page_links(url):
                self.crawl(link, current_depth + 1)

    def start(self):
        """启动爬虫"""
        start_url = f"{self.base_url}/display/{self.space_key}"
        print(f"开始爬取空间: {self.space_key}")
        self.crawl(start_url)
        print(f"\n完成! 共生成 {len(self.visited_urls)} 个PDF文件")

if __name__ == "__main__":
    # 配置参数
    CONFLUENCE_URL = "https://wiki.your-company.com"
    USERNAME = "your-username"
    PASSWORD = "your-password"  # 或用API Token
    SPACE_KEY = "DEV"  # Confluence空间Key
    
    # 启动爬虫
    crawler = ConfluenceTextCrawler(
        base_url=CONFLUENCE_URL,
        username=USERNAME,
        password=PASSWORD,
        space_key=SPACE_KEY,
        max_depth=2  # 文本版建议降低深度
    )
    crawler.start()