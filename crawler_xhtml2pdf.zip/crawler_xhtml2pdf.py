import os
import re
import time
import random
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from xhtml2pdf import pisa
from io import BytesIO
import ssl

class ConfluencePDFCrawler:
    def __init__(self, base_url, username, password, space_key, max_depth=3, output_dir="confluence_pdfs"):
        """
        初始化爬虫 (基于xhtml2pdf)
        :param base_url: Confluence 基础URL (如 "https://wiki.your-company.com")
        :param username: 用户名
        :param password: 密码或API Token
        :param space_key: 空间Key (如 "DEV")
        :param max_depth: 最大爬取深度
        :param output_dir: PDF输出目录
        """
        self.base_url = base_url.rstrip('/')
        self.space_key = space_key
        self.max_depth = max_depth
        self.output_dir = output_dir
        self.visited_urls = set()
        
        # 配置会话（绕过SSL验证 + 认证）
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.verify = False  # 跳过SSL验证（生产环境应配置证书）
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'text/html,application/xhtml+xml'
        })
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)

    def _fix_confluence_html(self, html):
        """修复Confluence的HTML使其兼容xhtml2pdf"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # 移除不兼容元素
        for element in soup.select('script, style, iframe, header, footer, .sidebar'):
            element.decompose()
        
        # 修复图片路径
        for img in soup.select('img[src]'):
            if not img['src'].startswith(('http', 'data:')):
                img['src'] = urljoin(self.base_url, img['src'])
        
        # 添加基础CSS样式
        style = soup.new_tag('style')
        style.string = """
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            pre { background: #f5f5f5; padding: 10px; }
        """
        soup.head.append(style)
        
        return str(soup)

    def save_as_pdf(self, url):
        """使用xhtml2pdf保存页面为PDF"""
        try:
            # 获取页面HTML
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            # 修复HTML
            fixed_html = self._fix_confluence_html(response.text)
            filename = f"{urlparse(url).path.replace('/', '_')[1:50]}.pdf"
            filepath = os.path.join(self.output_dir, filename)
            
            # 生成PDF
            with open(filepath, "wb") as f:
                pisa_status = pisa.CreatePDF(
                    src=fixed_html,
                    dest=f,
                    encoding='UTF-8',
                    link_callback=lambda uri: urljoin(url, uri)
                )
            
            if not pisa_status.err:
                print(f"✓ 已保存: {filepath}")
                return True
            else:
                print(f"✗ PDF生成错误: {pisa_status.err}")
                return False
                
        except Exception as e:
            print(f"✗ 处理失败 [{url}]: {str(e)}")
            return False

    def get_page_links(self, url):
        """获取页面中的所有有效链接"""
        try:
            time.sleep(random.uniform(1, 3))  # 反爬延迟
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            links = set()
            for a in soup.select('a[href^="/display/"], a[href^="/pages/"]'):
                full_url = urljoin(self.base_url, a['href'])
                if full_url not in self.visited_urls:
                    links.add(full_url)
            return links
        except Exception as e:
            print(f"链接提取失败: {url} - {str(e)}")
            return set()

    def crawl(self, url, current_depth=1):
        """递归爬取页面"""
        if current_depth > self.max_depth or url in self.visited_urls:
            return
        
        self.visited_urls.add(url)
        print(f"\n深度 {current_depth}: 正在处理 {url}")
        
        # 保存当前页为PDF
        self.save_as_pdf(url)
        
        # 获取并处理子链接
        if current_depth < self.max_depth:
            for link in self.get_page_links(url):
                self.crawl(link, current_depth + 1)

    def start(self):
        """启动爬虫"""
        start_url = f"{self.base_url}/display/{self.space_key}"
        print(f"🚀 开始爬取空间: {self.space_key}")
        self.crawl(start_url)
        print(f"\n✅ 完成! 共生成 {len(self.visited_urls)} 个PDF文件")

if __name__ == "__main__":
    # 配置参数
    CONFLUENCE_URL = "https://confluence.your-company.com"
    USERNAME = "your-username"
    PASSWORD = "your-password"  # 或用API Token
    SPACE_KEY = "DEV"  # Confluence空间Key
    
    # 启动爬虫
    crawler = ConfluencePDFCrawler(
        base_url=CONFLUENCE_URL,
        username=USERNAME,
        password=PASSWORD,
        space_key=SPACE_KEY,
        max_depth=2  # 建议先测试深度2
    )
    crawler.start()