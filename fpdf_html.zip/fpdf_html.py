from fpdf import FPDF
from bs4 import BeautifulSoup
import re

class HTML2PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Confluence Export', 0, 1, 'C')
    
    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def add_html_content(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        self.set_font("Arial", size=12)
        
        for element in soup.find_all(['p', 'h1', 'h2', 'h3', 'li']):
            text = element.get_text().strip()
            if text:
                if element.name == 'h1':
                    self.set_font('Arial', 'B', 16)
                    self.cell(0, 10, text, ln=1)
                elif element.name == 'h2':
                    self.set_font('Arial', 'B', 14)
                    self.cell(0, 8, text, ln=1)
                elif element.name == 'h3':
                    self.set_font('Arial', 'B', 12)
                    self.cell(0, 6, text, ln=1)
                else:
                    self.set_font('Arial', size=12)
                    self.multi_cell(0, 5, text)
                self.ln(4)

def convert_html_to_pdf(html_content, output_path):
    pdf = HTML2PDF()
    pdf.add_page()
    pdf.add_html_content(html_content)
    pdf.output(output_path)

# 使用示例
html = "<h1>Test</h1><p>This is a test paragraph.</p>"
convert_html_to_pdf(html, "output.pdf")